<?php

use App\Models\Game;
use Database\Seeders\GameSeeder;
use Illuminate\Foundation\Testing\LazilyRefreshDatabase;

uses(LazilyRefreshDatabase::class);

it('returns a game list with the contract fields and stable types', function () {
    $this->travelTo(new DateTimeImmutable('2026-10-09T08:00:00Z'));
    $game = Game::factory()->create(['title' => 'Game Contoh', 'is_free' => false]);

    $this->getJson('/api/games')->assertOk()->assertExactJson([
        'data' => [[
            'id' => $game->id, 'title' => 'Game Contoh', 'platform' => 'pc',
            'is_free' => false, 'source' => 'fixture', 'updated_at' => '2026-10-09T08:00:00.000000Z',
        ]],
    ]);
});

it('returns an empty list with 200 when no games exist', function () {
    $this->getJson('/api/games')->assertOk()->assertExactJson(['data' => []]);
});

it('filters games by platform', function () {
    $pcGame = Game::factory()->create();
    Game::factory()->create(['platform' => 'browser']);

    $this->getJson('/api/games?platform=pc')->assertOk()
        ->assertJsonCount(1, 'data')->assertJsonPath('data.0.id', $pcGame->id);
});

it('returns 422 for unsupported query parameters', function (string $query) {
    $this->getJson('/api/games?'.$query)->assertUnprocessable()->assertExactJson([
        'message' => 'The given data was invalid.',
        'errors' => ['platform' => ['Gunakan platform pc atau browser; hanya parameter platform yang didukung.']],
    ]);
})->with(['invalid platform' => 'platform=console', 'empty platform' => 'platform=', 'array platform' => 'platform[]=pc', 'unknown query' => 'limit=5']);

it('returns a game detail as one object', function () {
    $game = Game::factory()->create();

    $this->getJson('/api/games/'.$game->id)->assertOk()
        ->assertJsonPath('data.id', $game->id)->assertJsonPath('data.is_free', true)
        ->assertJsonStructure(['data' => ['id', 'title', 'platform', 'is_free', 'source', 'updated_at']]);
});

it('returns 404 with the contract error for missing or invalid ids', function (string $id) {
    $this->getJson('/api/games/'.$id)->assertNotFound()
        ->assertExactJson(['message' => 'Resource not found', 'errors' => null]);
})->with(['missing' => '999999', 'non numeric' => 'abc', 'zero' => '0']);

it('does not expose a create game endpoint', function () {
    $this->postJson('/api/games', ['title' => 'Cannot create'])->assertMethodNotAllowed();
    $this->assertDatabaseCount('games', 0);
});

it('keeps development seed data stable when seeding twice', function () {
    $this->seed(GameSeeder::class);
    $this->seed(GameSeeder::class);

    $this->assertDatabaseCount('games', 2);
});
