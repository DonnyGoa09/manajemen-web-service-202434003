<?php

namespace App\Http\Controllers;

use App\Models\Game;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GameController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $parameters = $request->query();

        if (array_diff(array_keys($parameters), ['platform']) !== []
            || (array_key_exists('platform', $parameters)
                && ! in_array($parameters['platform'], ['pc', 'browser'], true))) {
            return response()->json([
                'message' => 'The given data was invalid.',
                'errors' => ['platform' => ['Gunakan platform pc atau browser; hanya parameter platform yang didukung.']],
            ], 422);
        }

        $games = Game::query()->orderBy('id');

        if (array_key_exists('platform', $parameters)) {
            $games->where('platform', $parameters['platform']);
        }

        return response()->json(['data' => $games->get()->map(fn (Game $game): array => $this->gameData($game))]);
    }

    public function show(string $game): JsonResponse
    {
        $gameModel = ctype_digit($game) && (int) $game > 0 ? Game::find($game) : null;

        if ($gameModel === null) {
            return response()->json(['message' => 'Resource not found', 'errors' => null], 404);
        }

        return response()->json(['data' => $this->gameData($gameModel)]);
    }

    /** @return array{id: int, title: string, platform: string, is_free: bool, source: string, updated_at: string} */
    private function gameData(Game $game): array
    {
        return [
            'id' => $game->id, 'title' => $game->title, 'platform' => $game->platform,
            'is_free' => $game->is_free, 'source' => $game->source,
            'updated_at' => $game->updated_at->toISOString(),
        ];
    }
}
