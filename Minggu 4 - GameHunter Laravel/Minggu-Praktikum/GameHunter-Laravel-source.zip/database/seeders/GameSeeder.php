<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GameSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        foreach (['Game Contoh PC' => 'pc', 'Game Contoh Browser' => 'browser'] as $title => $platform) {
            if (! DB::table('games')->where('title', $title)->where('source', 'fixture')->exists()) {
                DB::table('games')->insert([
                    'title' => $title, 'platform' => $platform,
                    'is_free' => true, 'source' => 'fixture',
                    'created_at' => now(), 'updated_at' => now(),
                ]);
            }
        }
    }
}
